# 初始化空的元组列表 A
A = []

# 打开文件进行读取
with open('input.txt', 'r') as file:
    for line in file:
        # 去除行尾的换行符并按空白字符分割行内容
        parts = line.strip().split()
        if len(parts) >= 5:
            # 获取第五列内容
            fifth_col = parts[4]
            # 检查 > 前后是否有值
            if '>' in fifth_col:
                left, right = fifth_col.split('>', 1)
                if left.strip() and right.strip():
                    # 提取第三列、第四列和第五列内容
                    third_col = parts[2]
                    fourth_col = parts[3]
                    combined_str = f"{third_col}:{fourth_col}:{fifth_col}"
                    found = False
                    for i, (_, _, count) in enumerate(A):
                        if A[i][1] == combined_str:
                            # 如果字符串已存在，更新计数
                            A[i] = (third_col, combined_str, count + 1)
                            found = True
                            break
                    if not found:
                        # 如果字符串不存在，添加新元组
                        A.append((third_col, combined_str, 1))

# 输出元组列表 A 中的各元组内容
for item in A:
    print(item)

# 统计元组中第一个元素相同的元组个数
first_element_count = {}
for first, _, _ in A:
    if first in first_element_count:
        first_element_count[first] += 1
    else:
        first_element_count[first] = 1

# 输出元组中第一个元素相同的元组个数
for key, value in first_element_count.items():
    print(f"控制器 {key} 的transition个数: {value}")

# 输出列表 A 中的元组总数
print(f"总的transiton个数: {len(A)}")
