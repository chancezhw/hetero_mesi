import os
import re
import sys

if len(sys.argv) != 2:
    print({len(sys.argv)})
    print("输入的参数数量不正确，请提供一个参数")
    sys.exit(1)
    
mem_name = sys.argv[1]
if mem_name == 'dev':
    source_folder = 'result_dev_mem'
    total_num = [66, 36, 139, 87]
elif mem_name == 'host':
    source_folder = 'result_host_mem'
    total_num = [54, 27, 152, 54]
else:
    print("Error：mem_name必须为dev或者host！")
    
# 定义源文件夹路径和输出文件路径
# source_folder = 'result_dev_mem'
output_file = 'merged.txt'
res_file_path = 'res2.txt'

# 检查源文件夹是否存在
if not os.path.exists(source_folder):
    print(f"源文件夹 {source_folder} 不存在。")
else:
    # 获取源文件夹中所有的txt文件
    txt_files = [f for f in os.listdir(source_folder) if f.endswith('.txt')]

    if not txt_files:
        print(f"源文件夹 {source_folder} 中没有txt文件。")
    else:
        try:
            # 打开输出文件以写入合并后的内容
            with open(output_file, 'w', encoding='utf-8') as outfile:
                file_count = 0
                for txt_file in txt_files:
                    file_path = os.path.join(source_folder, txt_file)
                    # 打开每个txt文件并逐行读取内容
                    with open(file_path, 'r', encoding='utf-8') as infile:
                        for line in infile:
                            outfile.write(line)
                    # 在每个文件内容之间添加一个空行作为分隔
                    outfile.write('\n')
                    file_count += 1
            print(f"所有txt文件已成功合并到 {output_file}。")
        except Exception as e:
            print(f"合并文件时出现错误: {e}")

print(f"一共合并了{file_count}个源文件，下面开始分析 merged.txt")
# 初始化空列表 A
A = []

# 定义目标控制器列表
target_controllers = [
    "L1Cache_Controller",
    "DeviceCache_Controller",
    "HaDirectory_Controller",
    "DcohDirectory_Controller"
]

try:
    # 打开文件并读取内容
    with open('merged.txt', 'r') as file:
        for line in file:
            # 找到第一个空格的位置, 删除第一个空格及之后的内容
            space_index = line.find(' ')
            if space_index != -1:
                line = line[:space_index]
            # 找到第一个:的位置, 删除第一个:及之后的内容
            colon_index = line.find(':')
            if colon_index != -1:
                line = line[:colon_index]
            # 以 . 和 | 为分隔符拆分内容
            columns = []
            parts = line.strip().split('.')
            for part in parts:
                columns.extend(part.split('|'))

            # 检查列数是否为 5
            if len(columns) == 5:
                third_col = columns[2]
                # 检查第三列是否为目标控制器之一
                if third_col in target_controllers:
                    fourth_col = columns[3]
                    fifth_col = columns[4]
                    # 将第三、四、五列用冒号连接
                    combined_str = f"{third_col}:{fourth_col}:{fifth_col}"
                    # 检查连接后的字符串是否已在列表 A 中
                    if combined_str not in [t[1] for t in A]:
                        new_tuple = (third_col, combined_str)
                        A.append(new_tuple)
except FileNotFoundError:
    print("未找到指定的文件，请检查文件路径和文件名。")

# 按行输出元组列表 A 中的各元组内容
print("覆盖到的transitions如下：")
for tup in A:
    print(tup)

# 按行输出元组列表 A 中的各元组内容到文件
try:
    with open(res_file_path, 'w', encoding='utf-8') as output_file:
        for tup in A:
            # 将元组转换为字符串并写入文件
            output_file.write(f"({tup[0]}, {tup[1]})\n")
    print(f"已将元组列表内容写入 {res_file_path}。\n")
except Exception as e:
    print(f"写入文件时出错: {e}")

# 统计元组中第一个元素相同的元组个数
controller_count = {}
for tup in A:
    controller = tup[0]
    if controller in controller_count:
        controller_count[controller] += 1
    else:
        controller_count[controller] = 1

# 输出每个控制器对应的元组个数
i = 0
for controller, count in controller_count.items():
    ratio =  "{:.2%}".format(count/total_num[i])
    i += 1
    print(f"{controller}覆盖到的transition个数: {count}, 覆盖率为：{ratio}")


# 输出列表 A 中的元组总数
total_ratio = "{:.2%}".format(len(A)/sum(total_num))
print(f"覆盖到的transitions总数: {len(A)}，总的覆盖率为:{total_ratio}")
print(f"\n一共合并了{file_count}个源文件")