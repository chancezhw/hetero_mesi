def read_tuples_from_file(file_path):
    tuples_list = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                # 去除行首尾的空白字符和括号
                line = line.strip().strip('()')
                # 分割字符串得到元组的元素
                elements = [element.strip() for element in line.split(',')]
                if len(elements) == 2:
                    # 创建元组并添加到列表中
                    tup = (elements[0], elements[1])
                    tuples_list.append(tup)
    except FileNotFoundError:
        print(f"文件 {file_path} 未找到。")
    return tuples_list

def compare_files(file1_path, file2_path):
    # 从第一个文件中读取元组
    tuples_file1 = read_tuples_from_file(file1_path)
    # 从第二个文件中读取元组
    tuples_file2 = read_tuples_from_file(file2_path)

    # 找出第二个文件中存在但第一个文件中不存在的元组
    unique_tuples = [tup for tup in tuples_file2 if tup not in tuples_file1]

    # 输出结果
    for tup in unique_tuples:
        print(tup)

# 请根据实际情况修改文件路径
file1_path = 'res1.txt'
file2_path = 'res2.txt'
compare_files(file1_path, file2_path)