print(f"开始分析单个文件：")
# 初始化空列表 A
A = []

# 定义目标控制器列表
target_controllers = [
    "L1Cache_Controller",
    "DeviceCache_Controller",
    "HaDirectory_Controller",
    "DcohDirectory_Controller"
]

try:
    # 打开文件并读取内容
    with open('result/stats-70000-8.txt', 'r') as file:
        for line in file:
            # 找到第一个空格的位置, 删除第一个空格及之后的内容
            space_index = line.find(' ')
            if space_index != -1:
                line = line[:space_index]
            # 找到第一个:的位置, 删除第一个:及之后的内容
            colon_index = line.find(':')
            if colon_index != -1:
                line = line[:colon_index]
            # 以 . 和 | 为分隔符拆分内容
            columns = []
            parts = line.strip().split('.')
            for part in parts:
                columns.extend(part.split('|'))

            # 检查列数是否为 5
            if len(columns) == 5:
                third_col = columns[2]
                # 检查第三列是否为目标控制器之一
                if third_col in target_controllers:
                    fourth_col = columns[3]
                    fifth_col = columns[4]
                    # 将第三、四、五列用冒号连接
                    combined_str = f"{third_col}:{fourth_col}:{fifth_col}"
                    # 检查连接后的字符串是否已在列表 A 中
                    if combined_str not in [t[1] for t in A]:
                        new_tuple = (third_col, combined_str)
                        A.append(new_tuple)
except FileNotFoundError:
    print("未找到指定的文件，请检查文件路径和文件名。")

# 按行输出元组列表 A 中的各元组内容
for tup in A:
    print(tup)

# 统计元组中第一个元素相同的元组个数
controller_count = {}
for tup in A:
    controller = tup[0]
    if controller in controller_count:
        controller_count[controller] += 1
    else:
        controller_count[controller] = 1

# 输出每个控制器对应的元组个数
for controller, count in controller_count.items():
    print(f"{controller} 的元组个数: {count}")

# 输出列表 A 中的元组总数
print(f"列表 A 中的元组总数: {len(A)}")
