This directory contains Dockerfiles used to create images used in the gem5 project.
The `docker-compose.yaml` defines the building of each image.
The images can be built locally using `docker-compose build`.
